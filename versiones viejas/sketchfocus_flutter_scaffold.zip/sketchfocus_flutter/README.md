# SketchFocus Flutter Scaffold

Este scaffold baja el diseño de Stitch a una arquitectura Flutter funcional con:

- `PomodoroController` para estado y temporizador.
- `SketchProgressPainter` para el anillo + dibujo procedural.
- 6 patrones alternables (`foxFace`, `catFace`, `mandala`, `fish`, `owl`, `leaf`).
- Pausa real: pausa tanto el contador como la revelación del dibujo.
- Transiciones automáticas entre focus, break y summary.
- Base visual tipo cuaderno/papel arrugado.

## Lo que sí resuelve

- Arquitectura desacoplada UI/lógica.
- Temporizador por fases.
- Dibujos procedurales sencillos y reproducibles.
- Resumen final.

## Lo que aún falta para cerrar bien el proyecto

1. Añadir fuentes manuscritas reales (`google_fonts` o assets locales).
2. Integrar notificaciones locales.
3. Implementar overlay Android con `flutter_overlay_window`.
4. Persistencia si la app se minimiza o se cierra.
5. Pruebas unitarias al controlador.

## Siguiente paso real

Mover esto a tu proyecto existente y reemplazar la UI estática generada por Stitch por estos widgets.
