import 'package:flutter/material.dart';
import 'screens/setup_screen.dart';
import 'core/theme/sketch_theme.dart';

class SketchFocusApp extends StatelessWidget {
  const SketchFocusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SketchFocus',
      theme: SketchTheme.light(),
      home: const SetupScreen(),
    );
  }
}
