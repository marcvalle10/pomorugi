import 'package:flutter/material.dart';
import '../models/session_summary.dart';
import '../widgets/paper_background.dart';
import '../widgets/sketch_card.dart';
import 'setup_screen.dart';

class SummaryScreen extends StatelessWidget {
  final SessionSummary summary;
  const SummaryScreen({super.key, required this.summary});

  String get message {
    if (summary.completedCycles <= 2) return 'Buen arranque. Ya tienes una sesión sólida.';
    if (summary.completedCycles <= 5) return 'Ritmo fuerte. La constancia ya se nota.';
    return 'Alto rendimiento. Cerraste la sesión con disciplina.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PaperBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('Session Summary', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 28),
                const Icon(Icons.task_alt, size: 110, color: Color(0xFFE0B600)),
                const SizedBox(height: 18),
                Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontSize: 30)),
                const SizedBox(height: 20),
                SketchCard(
                  rotation: -0.01,
                  child: Column(
                    children: [
                      _row('Ciclos completados', '${summary.completedCycles}'),
                      _row('Tiempo total de trabajo', summary.format(summary.totalFocusTime)),
                      _row('Tiempo total de descanso', summary.format(summary.totalBreakTime)),
                    ],
                  ),
                ),
                const Spacer(),
                FilledButton(
                  onPressed: () {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const SetupScreen()),
                      (route) => false,
                    );
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFFA9140),
                    foregroundColor: const Color(0xFF383835),
                    padding: const EdgeInsets.symmetric(vertical: 18),
                  ),
                  child: const Text('Nueva sesión'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 16))),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}
