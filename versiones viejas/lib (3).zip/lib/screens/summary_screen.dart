import 'package:flutter/material.dart';

import '../models/session_summary.dart';
import '../widgets/paper_background.dart';
import '../widgets/sketch_card.dart';
import 'setup_screen.dart';

class SummaryScreen extends StatelessWidget {
  static const routeName = '/summary';

  final SessionSummary summary;

  const SummaryScreen({super.key, required this.summary});

  String get message {
    if (summary.completedCycles <= 2) return '¡Buen arranque!';
    if (summary.completedCycles <= 5) return '¡High performance!';
    return '¡Nivel bestial!';
  }

  String get subtitle =>
      'You smashed it. ${summary.completedCycles} cycles completed.';

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF1C140D);
    const warmRed = Color(0xFFFF5F5F);
    const coolTeal = Color(0xFF2D9DA6);
    const sunnyYellow = Color(0xFFFFD93D);
    const softPurple = Color(0xFFA888FF);
    return Scaffold(
      body: PaperBackground(
        backgroundColor: const Color(0xFFFFF8E7),
        notebookLines: false,
        dotted: true,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 18),
            child: Column(
              children: [
                Row(
                  children: [
                    const SizedBox(width: 36),
                    const Spacer(),
                    const Text(
                      'Session Summary',
                      style: TextStyle(
                        fontFamily: 'Inter',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: ink,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () =>
                          Navigator.of(context).pushNamedAndRemoveUntil(
                            SetupScreen.routeName,
                            (r) => false,
                          ),
                      icon: const Icon(Icons.close, color: ink),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Stack(
                          clipBehavior: Clip.none,
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 170,
                              height: 170,
                              decoration: BoxDecoration(
                                color: sunnyYellow.withOpacity(0.25),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: ink,
                                  width: 4,
                                  style: BorderStyle.solid,
                                ),
                              ),
                              child: const Icon(
                                Icons.task_alt,
                                size: 92,
                                color: ink,
                              ),
                            ),
                            Positioned(
                              top: -4,
                              right: -4,
                              child: _sticker('AWESOME!', warmRed),
                            ),
                            Positioned(
                              top: -20,
                              left: -10,
                              child: Icon(
                                Icons.star,
                                color: sunnyYellow.withOpacity(0.9),
                                size: 28,
                              ),
                            ),
                            const Positioned(
                              bottom: -10,
                              right: 6,
                              child: Icon(
                                Icons.auto_awesome,
                                color: coolTeal,
                                size: 24,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                        Text(
                          message,
                          style: const TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 40,
                            fontWeight: FontWeight.w900,
                            color: ink,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          subtitle,
                          style: const TextStyle(
                            fontFamily: 'Inter',
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            color: Colors.black54,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _miniBar(coolTeal, 42),
                            const SizedBox(width: 6),
                            _miniBar(warmRed, 36),
                            const SizedBox(width: 6),
                            _miniBar(sunnyYellow, 52),
                          ],
                        ),
                        const SizedBox(height: 24),
                        SketchCard(
                          rotation: -0.012,
                          color: Colors.white,
                          shadowOffset: 6,
                          padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
                          child: Column(
                            children: [
                              _summaryRow(
                                Icons.sync,
                                coolTeal,
                                'Total Cycles',
                                '${summary.completedCycles}',
                              ),
                              const Divider(
                                height: 28,
                                color: Color(0x33222222),
                                thickness: 1,
                              ),
                              _summaryRow(
                                Icons.timer_outlined,
                                warmRed,
                                'Total Work',
                                '${summary.totalFocusTime.inMinutes} mins',
                              ),
                              const Divider(
                                height: 28,
                                color: Color(0x33222222),
                                thickness: 1,
                              ),
                              _summaryRow(
                                Icons.coffee_outlined,
                                softPurple,
                                'Total Break',
                                '${summary.totalBreakTime.inMinutes} mins',
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 26),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: () =>
                                Navigator.of(context).pushNamedAndRemoveUntil(
                                  SetupScreen.routeName,
                                  (route) => false,
                                ),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFF48C25),
                              foregroundColor: ink,
                              padding: const EdgeInsets.symmetric(vertical: 18),
                              side: const BorderSide(color: ink, width: 3),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              elevation: 6,
                            ),
                            child: const Text(
                              'Nueva Sesión',
                              style: TextStyle(
                                fontFamily: 'Inter',
                                fontSize: 28,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 26),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: const [
                            Icon(Icons.edit_square, color: warmRed, size: 34),
                            Icon(Icons.brush, color: coolTeal, size: 34),
                            Icon(Icons.draw, color: softPurple, size: 34),
                            Icon(
                              Icons.palette_outlined,
                              color: sunnyYellow,
                              size: 34,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _miniBar(Color color, double width) => Container(
    width: width,
    height: 6,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(8),
    ),
  );

  Widget _sticker(String text, Color color) {
    return Transform.rotate(
      angle: 0.18,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: color,
          border: Border.all(color: const Color(0xFF1C140D), width: 2),
          borderRadius: BorderRadius.circular(100),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontFamily: 'Inter',
            fontSize: 13,
            fontWeight: FontWeight.w900,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(
    IconData icon,
    Color iconColor,
    String label,
    String value,
  ) {
    return Row(
      children: [
        Icon(icon, color: iconColor),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              fontFamily: 'Inter',
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Colors.black54,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'Inter',
            fontSize: 30,
            fontWeight: FontWeight.w900,
            color: Color(0xFF1C140D),
          ),
        ),
      ],
    );
  }
}
