import 'package:flutter/material.dart';

class PaperBackground extends StatelessWidget {
  final Widget child;
  final Color backgroundColor;
  final bool notebookLines;
  final bool dotted;
  final bool leaves;

  const PaperBackground({
    super.key,
    required this.child,
    this.backgroundColor = const Color(0xFFFFD150),
    this.notebookLines = true,
    this.dotted = false,
    this.leaves = false,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(color: backgroundColor),
      child: CustomPaint(
        painter: _PaperPainter(
          notebookLines: notebookLines,
          dotted: dotted,
          leaves: leaves,
          backgroundColor: backgroundColor,
        ),
        child: child,
      ),
    );
  }
}

class _PaperPainter extends CustomPainter {
  final bool notebookLines;
  final bool dotted;
  final bool leaves;
  final Color backgroundColor;

  const _PaperPainter({
    required this.notebookLines,
    required this.dotted,
    required this.leaves,
    required this.backgroundColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (notebookLines) {
      final linePaint = Paint()
        ..color = const Color(0xFF6B5F46).withOpacity(0.08)
        ..strokeWidth = 1;
      const gap = 34.0;
      for (double y = 24; y < size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
      }
    }

    if (dotted) {
      final dotPaint = Paint()..color = const Color(0xFF1C140D).withOpacity(0.10);
      for (double x = 18; x < size.width; x += 22) {
        for (double y = 18; y < size.height; y += 22) {
          canvas.drawCircle(Offset(x, y), 1.2, dotPaint);
        }
      }
    }

    final wrinklePaint = Paint()
      ..color = Colors.black.withOpacity(0.025)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10;
    final path = Path()
      ..moveTo(size.width * .12, 0)
      ..quadraticBezierTo(size.width * .16, size.height * .18, size.width * .14, size.height * .35)
      ..quadraticBezierTo(size.width * .12, size.height * .55, size.width * .18, size.height);
    canvas.drawPath(path, wrinklePaint);

    if (leaves) {
      final leafPaint = Paint()
        ..color = const Color(0xFFF8FAFC).withOpacity(0.15)
        ..style = PaintingStyle.fill;
      _leaf(canvas, Offset(size.width * .12, size.height * .28), 32, -0.5, leafPaint);
      _leaf(canvas, Offset(size.width * .82, size.height * .18), 26, 0.4, leafPaint);
      _leaf(canvas, Offset(size.width * .18, size.height * .82), 24, 0.7, leafPaint);
      _leaf(canvas, Offset(size.width * .82, size.height * .78), 34, -0.8, leafPaint);
    }
  }

  void _leaf(Canvas canvas, Offset center, double size, double rotation, Paint paint) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rotation);
    final path = Path()
      ..moveTo(0, -size)
      ..quadraticBezierTo(size * 0.95, -size * 0.2, 0, size)
      ..quadraticBezierTo(-size * 0.95, -size * 0.2, 0, -size)
      ..close();
    canvas.drawPath(path, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _PaperPainter oldDelegate) =>
      oldDelegate.notebookLines != notebookLines ||
      oldDelegate.dotted != dotted ||
      oldDelegate.leaves != leaves ||
      oldDelegate.backgroundColor != backgroundColor;
}
