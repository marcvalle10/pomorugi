import 'package:flutter/material.dart';

class SketchTheme {
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFFFFCF7),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFFBC3100),
        primary: const Color(0xFFBC3100),
        secondary: const Color(0xFF237329),
        surface: const Color(0xFFFFFCF7),
      ),
      textTheme: const TextTheme(
        headlineMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Color(0xFF383835)),
        titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Color(0xFF383835)),
        bodyLarge: TextStyle(fontSize: 16, color: Color(0xFF383835)),
        bodyMedium: TextStyle(fontSize: 14, color: Color(0xFF383835)),
      ),
    );
  }
}
