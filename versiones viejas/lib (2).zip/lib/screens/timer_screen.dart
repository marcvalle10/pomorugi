import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/pomodoro_controller.dart';
import '../models/session_phase.dart';
import '../widgets/paper_background.dart';
import '../widgets/sketch_card.dart';
import '../widgets/sketch_progress_painter.dart';
import 'summary_screen.dart';

class TimerScreen extends StatefulWidget {
  static const routeName = '/timer';

  const TimerScreen({super.key});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  String breakMessage = 'Buen trabajo. Tómate un respiro.';
  PomodoroController? _controller;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final controller = context.read<PomodoroController>();

    if (_controller != controller) {
      _controller?.removeListener(_onControllerUpdate);
      _controller = controller;
      _controller!.addListener(_onControllerUpdate);

      if (!_controller!.isRunning &&
          _controller!.phase != SessionPhase.summary) {
        _controller!.start();
      }
    }
  }

  void _onControllerUpdate() {
    if (!mounted || _controller == null) return;

    if (_controller!.phase == SessionPhase.shortBreak) {
      breakMessage = _controller!.randomBreakMessage();
    }

    if (_controller!.phase == SessionPhase.summary) {
      Navigator.of(context).pushReplacementNamed(
        SummaryScreen.routeName,
        arguments: _controller!.buildSummary(),
      );
      return;
    }

    setState(() {});

    if (!_controller!.isRunning) {
      Future.delayed(const Duration(milliseconds: 650), () {
        if (!mounted || _controller == null) return;

        if (_controller!.phase != SessionPhase.summary &&
            !_controller!.isRunning) {
          _controller!.start();
        }
      });
    }
  }

  @override
  void dispose() {
    _controller?.removeListener(_onControllerUpdate);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<PomodoroController>();
    final isBreak = c.phase == SessionPhase.shortBreak;

    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 500),
        color: isBreak ? const Color(0xFFE6FBF8) : const Color(0xFFFFFCF7),
        child: PaperBackground(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: _confirmExit,
                        icon: const Icon(Icons.close),
                      ),
                      const Spacer(),
                      Text(
                        'Ciclo ${c.currentCycle} de ${c.config.totalCycles}',
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    c.statusLabel,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isBreak ? breakMessage : 'De los trazos al enfoque.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 18),
                  Expanded(
                    child: Center(
                      child: SizedBox(
                        width: 320,
                        height: 320,
                        child: CustomPaint(
                          painter: SketchProgressPainter(
                            progress: c.phaseProgress,
                            sketchReveal: c.sketchRevealProgress,
                            chaosVisibility: c.chaosVisibility,
                            isBreak: isBreak,
                            pattern: c.pattern,
                          ),
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  c.formattedRemaining,
                                  style: const TextStyle(
                                    fontSize: 44,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(isBreak ? 'BREAK MODE' : 'TRABAJANDO'),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SketchCard(
                    rotation: 0.01,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        OutlinedButton(
                          onPressed: _confirmExit,
                          child: const Text('Salir'),
                        ),
                        FilledButton(
                          onPressed: c.toggle,
                          style: FilledButton.styleFrom(
                            backgroundColor: isBreak
                                ? const Color(0xFF56C5C8)
                                : const Color(0xFFFA6B6B),
                            foregroundColor: const Color(0xFF383835),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 18,
                            ),
                          ),
                          child: Text(c.isRunning ? 'Pausar' : 'Reanudar'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _confirmExit() async {
    final controller = context.read<PomodoroController>();
    controller.pause();

    final exit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Abandonar sesión'),
        content: const Text('Se perderá el progreso actual.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Salir'),
          ),
        ],
      ),
    );

    if (!mounted) return;

    if (exit == true) {
      Navigator.of(context).pop();
    } else {
      controller.start();
    }
  }
}
