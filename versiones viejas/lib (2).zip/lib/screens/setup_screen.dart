import 'package:flutter/material.dart';

import '../models/pomodoro_config.dart';
import '../widgets/paper_background.dart';
import '../widgets/sketch_card.dart';
import 'timer_screen.dart';

class SetupScreen extends StatefulWidget {
  static const routeName = '/';

  const SetupScreen({super.key});

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  double work = 25;
  double shortBreak = 5;
  double cycles = 4;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PaperBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'SketchFocus',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                const Text(
                  'Temporizador Pomodoro con trazos vivos sobre papel.',
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: SketchCard(
                    rotation: -0.01,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Configura tu sesión',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 16),
                        _slider(
                          'Trabajo',
                          work,
                          1,
                          60,
                          Colors.redAccent,
                          (v) => setState(() => work = v),
                        ),
                        _slider(
                          'Descanso',
                          shortBreak,
                          1,
                          30,
                          Colors.teal,
                          (v) => setState(() => shortBreak = v),
                        ),
                        _slider(
                          'Ciclos',
                          cycles,
                          1,
                          8,
                          Colors.amber.shade700,
                          (v) => setState(() => cycles = v),
                        ),
                        const Spacer(),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFFA9140),
                              foregroundColor: const Color(0xFF383835),
                              padding: const EdgeInsets.symmetric(vertical: 18),
                            ),
                            onPressed: () {
                              final config = PomodoroConfig(
                                workMinutes: work.round(),
                                breakMinutes: shortBreak.round(),
                                totalCycles: cycles.round(),
                              );

                              Navigator.of(context).pushNamed(
                                TimerScreen.routeName,
                                arguments: config,
                              );
                            },
                            child: const Text('Empezar'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _slider(
    String label,
    double value,
    double min,
    double max,
    Color color,
    ValueChanged<double> onChanged,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label  ${value.round()} min',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: (max - min).round(),
            activeColor: color,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
