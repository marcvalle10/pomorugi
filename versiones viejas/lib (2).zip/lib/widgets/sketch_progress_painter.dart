import 'dart:math';
import 'package:flutter/material.dart';
import '../services/sketch_generator.dart';

class SketchProgressPainter extends CustomPainter {
  final double progress;
  final double sketchReveal;
  final double chaosVisibility;
  final bool isBreak;
  final SketchPattern pattern;

  SketchProgressPainter({
    required this.progress,
    required this.sketchReveal,
    required this.chaosVisibility,
    required this.isBreak,
    required this.pattern,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = min(size.width, size.height) / 2 - 18;

    final baseRing = Paint()
      ..color = (isBreak ? const Color(0xFF56C5C8) : const Color(0xFFFA6B6B)).withOpacity(0.18)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, baseRing);

    final progressRing = Paint()
      ..color = isBreak ? const Color(0xFF56C5C8) : const Color(0xFFFA6B6B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round;
    final start = -pi / 2;
    canvas.drawArc(Rect.fromCircle(center: center, radius: radius), start, 2 * pi * progress, false, progressRing);

    _paintSketch(canvas, Rect.fromCircle(center: center, radius: radius - 28));
  }

  void _paintSketch(Canvas canvas, Rect rect) {
    final chaosPaint = Paint()
      ..color = const Color(0xFF383835).withOpacity(0.18 * chaosVisibility)
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (final stroke in pattern.chaosStrokes) {
      chaosPaint.strokeWidth = stroke.width;
      final path = _strokePath(stroke, rect, 1);
      canvas.drawPath(path, chaosPaint);
    }

    final revealCount = (pattern.guideStrokes.length * sketchReveal).ceil().clamp(0, pattern.guideStrokes.length);
    final revealPaint = Paint()
      ..color = const Color(0xFF383835)
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < revealCount; i++) {
      final stroke = pattern.guideStrokes[i];
      revealPaint.strokeWidth = stroke.width;
      final localFraction = (sketchReveal * pattern.guideStrokes.length) - i;
      final path = _strokePath(stroke, rect, localFraction.clamp(0, 1));
      canvas.drawPath(path, revealPaint);
    }
  }

  Path _strokePath(SketchStroke stroke, Rect rect, double fraction) {
    final pts = stroke.points;
    if (pts.isEmpty) return Path();
    final maxPoints = (pts.length * fraction).ceil().clamp(1, pts.length);
    final path = Path();
    final first = _map(pts.first, rect);
    path.moveTo(first.dx, first.dy);
    for (int i = 1; i < maxPoints; i++) {
      final p = _map(pts[i], rect);
      path.lineTo(p.dx, p.dy);
    }
    return path;
  }

  Offset _map(Offset unit, Rect rect) => Offset(rect.left + unit.dx * rect.width, rect.top + unit.dy * rect.height);

  @override
  bool shouldRepaint(covariant SketchProgressPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.sketchReveal != sketchReveal ||
        oldDelegate.chaosVisibility != chaosVisibility ||
        oldDelegate.isBreak != isBreak ||
        oldDelegate.pattern != pattern;
  }
}
