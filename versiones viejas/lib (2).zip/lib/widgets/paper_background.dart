import 'package:flutter/material.dart';

class PaperBackground extends StatelessWidget {
  final Widget child;
  const PaperBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        color: Color(0xFFFFFCF7),
      ),
      child: CustomPaint(
        painter: _PaperPainter(),
        child: child,
      ),
    );
  }
}

class _PaperPainter extends CustomPainter {
  const _PaperPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = const Color(0xFFE7E2D8)
      ..strokeWidth = 1;
    const gap = 28.0;
    for (double y = 22; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }

    final marginPaint = Paint()
      ..color = const Color(0xFFB8D8E8).withOpacity(0.65)
      ..strokeWidth = 1.5;
    canvas.drawLine(const Offset(42, 0), Offset(42, size.height), marginPaint);

    final wrinklePaint = Paint()
      ..color = const Color(0xFF383835).withOpacity(0.03)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 10;
    final path = Path()
      ..moveTo(size.width * .12, 0)
      ..quadraticBezierTo(size.width * .16, size.height * .18, size.width * .14, size.height * .35)
      ..quadraticBezierTo(size.width * .12, size.height * .55, size.width * .18, size.height);
    canvas.drawPath(path, wrinklePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
