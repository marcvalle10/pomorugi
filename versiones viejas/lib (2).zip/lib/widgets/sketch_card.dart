import 'package:flutter/material.dart';

class SketchCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final double rotation;

  const SketchCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.rotation = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: rotation,
      child: CustomPaint(
        painter: _SketchBorderPainter(),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: color ?? Colors.white.withOpacity(.80),
          ),
          child: child,
        ),
      ),
    );
  }
}

class _SketchBorderPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(2, 2, size.width - 4, size.height - 4);
    final path = Path()
      ..moveTo(rect.left + 12, rect.top + 3)
      ..quadraticBezierTo(rect.center.dx, rect.top - 1, rect.right - 10, rect.top + 5)
      ..quadraticBezierTo(rect.right + 2, rect.center.dy * .30, rect.right - 4, rect.bottom - 12)
      ..quadraticBezierTo(rect.center.dx, rect.bottom + 2, rect.left + 9, rect.bottom - 5)
      ..quadraticBezierTo(rect.left - 2, rect.center.dy * 1.15, rect.left + 4, rect.top + 10)
      ..close();

    final fill = Paint()..color = Colors.white.withOpacity(0.75);
    canvas.drawPath(path, fill);

    final border = Paint()
      ..color = const Color(0xFF383835)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2;
    canvas.drawPath(path, border);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
